# Karaye Digital Network — Android app project

This Android app opens the existing website inside a mobile app shell:
https://karayedigitalnetwork.lovable.app

## Build and download the APK using GitHub Actions
1. Download and unzip this project.
2. Open your GitHub repository: https://github.com/hukaraye3-bit/https-karayedigitalnetwork.lovable.app
3. Upload the files and folders from this project to the repository's root (keep the `.github/workflows/build-apk.yml` file; enable viewing hidden files if needed).
4. Commit the changes to the `main` branch.
5. Open the repository's **Actions** tab and select **Build Android APK**.
6. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `Karaye-Digital-Network-APK`.
7. Unzip the artifact on your phone or computer to get `app-debug.apk`. On Android, open the APK and follow the installation prompts. You may need to allow your browser/file manager to install unknown apps.

## Notes
- This project source is not itself an APK binary.
- The GitHub Actions workflow builds the APK in GitHub's hosted runner; this environment does not have Android SDK/Gradle installed, so it cannot compile the binary directly here.
- The app depends on the website remaining online.
- Do not process real customer payments unless payment processing is securely implemented and tested on the website.
- For Google Play release, create a signed release build and complete Play Console requirements; the debug APK is for direct testing/distribution.
